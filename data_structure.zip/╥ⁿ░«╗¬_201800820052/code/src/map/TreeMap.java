package map;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Queue;
//TreeMap使用红黑树来实现, 红黑树的节点中存储的是key-value键值对
public class TreeMap<K, V> implements tMap<K, V> {
    private String corl;
    private int size;
    private static final boolean Corred = false;
    private static final boolean Corblack = true;
    private Node<K, V> rootnode;// 定义根节点
    private Comparator<K> mycomparator; // 定义比较器
    public TreeMap(Comparator<K> comparator) {
        this.mycomparator = comparator;
    }
    public TreeMap() {
        this(null);
    }
    //****************************定义相关方法****************************************************************************
    //return：map的元素个数
    public int size() {
        return size;
    }
    //return：判断map是否为空。空：true;非空：false
    public boolean isEmpty() {
        return size == 0;
    }
    //return:清空当前map(通过root=null,size=0)
    public void clear() {
        rootnode = null;
        size = 0;
    }
    //向map中添加一个键值对（通过向TreeMap中添加一个结点）   参数：key 键；value 值   return：返回之前被覆盖的值
    public V put(K key, V value) {
        TreeCheck(key);
        // 添加第一个节点
        if (rootnode == null) {
            // 给根节点赋值,且根节点没有父节点
            rootnode = new Node<>(key, value, null);
            size++;
            // 添加节点之后的处理
            Addafter(rootnode);
            return null;
        }
        // 添加的不是第一个节点
        Node<K, V> parent = rootnode; // 这个是第一次比较的父节点
        Node<K, V> node = rootnode;
        int count = 0;
        while (node != null) {
            count = mycompare(key, node.key);   // 两者具体比较的方法
            parent = node; // 记录其每一次比较的父节点
            if (count > 0) {
                // 插入的元素大于根节点的元素,插入到根节点的右边
                node = node.right;
            } else if (count < 0) {
                // 插入的元素小于根节点的元素,插入到根节点的左边
                node = node.left;
            } else { // 相等
                node.key = key;
                V ValueBefore = node.value;
                node.value = value;
                return ValueBefore; // 返回之前node的value
            }
        }
        // 看看插入到父节点的哪个位置
        Node<K, V> newNode = new Node<>(key, value, parent);
        if (count > 0) {
            parent.right = newNode;
        } else {
            parent.left = newNode;
        }
        size++;
        // 添加节点之后的逻辑
        Addafter(newNode);
        // 这里的key是第一次加进去的, 之前没有值, 所以返回null
        return null;
    }
    //获取K值对应的value 参数：key 键 return:K值对应的value
    public V get(K key) {
        Node<K, V> node = getnodevalue(key);
        return node != null ? node.value : null;
    }
    //删除K值对应的键值对   参数：key 键
    public V remove(K key) {
        //return remove(node(key));
        Node<K, V> node=getnodevalue(key);
        if (node == null) return null;
        // node 不为空, 必然要删除结点, 先size--;
        size--;
        V ValueBefore = node.value;
        // 删除node是度为2的结点
        if (node.WhetherTwoChildren()) {
            //1、找到前驱
            Node<K, V> NodeAhead = NodeAhead(node);
            //2、用前驱节点的值覆盖度为2节点的值
            node.key = NodeAhead.key;
            node.value = NodeAhead.value;
            //3、删除前驱节点
            node = NodeAhead;
        }
        // 删除node,即删除后继节点 (node节点必然是度为1或0)
        // 因为node只有一个子节点/0个子节点, 如果其left!=null, 则用node.left来替代, node.left==null, 用node.right来替代,
        // 若node为叶子节点, 说明, node.left==null, node.right也为null, 则replacement==null;
        Node<K, V> substitution = node.left != null ? node.left : node.right;
        // 删除node是度为1的结点
        if (substitution != null) {
            // 更改parent
            substitution.parent = node.parent;
            // 更改parent的left、right的指向
            if (node.parent == null) {  // node是度为1且是根节点
                rootnode = substitution;
            } else if (node == node.parent.left) {
                node.parent.left = substitution;
            } else if (node == node.parent.right) {
                node.parent.right = substitution;
            }
            // 删除结点之后的处理
            RemoveAfter(node, substitution);
            // 删除node是叶子节点, 且是根节点
        } else if (node.parent == null) {
            rootnode = null;
            // 删除结点之后的处理
            RemoveAfter(node, null);
        } else { // node是叶子结点, 且不是根节点
            if (node == node.parent.left) {
                node.parent.left = null;
            } else {  // node == node.parent.right
                node.parent.right = null;
            }
            // 删除结点之后的处理
            RemoveAfter(node, null);
        }
        return ValueBefore;
    }
    //判断是否包含某个K值  参数：key 键  return:包含：true;不包含：false
    public boolean containsKey(K key) {
        return getnodevalue(key) != null;
    }
    //判断是否包含某个value值  参数：value 值  return:包含：true;不包含：false
    public boolean containsValue(V value) {
        if (rootnode == null) return false;
        // 层序遍历代码
        Queue<Node<K, V>> myqueue = new LinkedList<>();
        myqueue.offer(rootnode);
        while (!myqueue.isEmpty()) {
            Node<K, V> node = myqueue.poll();
            if (value == null ? node.value == null : value.equals(node.value))
                return true; // 说明存在

            if (node.left != null)
                myqueue.offer(node.left);

            if (node.right != null)
                myqueue.offer(node.right);
        }
        return false;
    }
    //遍历map  参数：Visitor<K, V>[泛型：可以让map更加通用（存放任意类型的数据）]
    public void traversal(Visitor<K, V> visitor) {
        if (visitor == null) return;
        mytraversal(rootnode, visitor);
    }
    //迭代实现mytraversal
    //*************************其他补充方法和类***************************************************************************
    private void mytraversal(Node<K, V> node, Visitor<K, V> visitor) {
        if (visitor.quit|| node == null ) return;
        mytraversal(node.left, visitor);

        if (visitor.quit) return;
        visitor.visitnode(node.key, node.value);
        mytraversal(node.right, visitor);
    }
    //声明节点 Node<K, V>
    private static class Node<K, V> {
        boolean color = Corred;
        K key;
        V value;
        Node<K, V> left;
        Node<K, V> right;
        Node<K, V> parent;
        public Node<K, V> sibling() {
            if (isLchild()) {
                return parent.right;
            }
            if (isRchild()) {
                return parent.left;
            }
            return null;
        }
        public Node(K key, V value, Node<K, V> parent) {
            this.parent = parent;
            this.key = key;
            this.value = value;
        }
        public boolean isRchild() {
            return parent != null && this == parent.right;
        }
        public boolean isLchild() {
            return parent != null && this == parent.left;
        }
        public boolean WhetherTwoChildren() {
            return left != null && right != null;
        }
    }
    //根据传入的节点, 返回该节点的前驱节点 (中序遍历)
    private Node<K, V> NodeAhead(Node<K, V> node) {
        if (node == null) return node;
        // (中序遍历)前驱节点在左子树当中(node.left.right.right.right...)
        Node<K, V> p = node.left;
        // 左子树存在
        if (p != null) {
            while (p.right != null) {
                p = p.right;
            }
            return p;
        }
        // 程序走到这里说明左子树不存在; 从父节点、祖父节点中寻找前驱节点
        /*
            node的父节点不为空 && node是其父节点的左子树时. 就一直往上寻找它的父节点
            因为node==node.parent.right, 说明你在你父节点的右边, 那么node.parent就是其node的前驱节点
         */
        while (node.parent != null && node == node.parent.left) {
            node = node.parent;
        }
        // 到达这一步表示: 两种情况如下
        // node.parent == null 表示没有父节点(根节点),返回空 ==> return node.parent;
        // node==node.parent.right 说明你在你父节点的右边, 那么node.parent就是其node的前驱节点 ==> return node.parent;
        return node.parent;
    }
    //对node进行右或左旋转  参数： rotnode
    private void rotateRightorLeft(Node<K, V> rotnode,String RorL) {
        if (RorL=="right"){
            Node<K, V> parent = rotnode.left;
            Node<K, V> child = parent.right;
            rotnode.left = child;
            parent.right = rotnode;
            afterRotate(rotnode, parent, child);
        }
        else {
            Node<K, V> parent = rotnode.right;
            Node<K, V> child = parent.left;
            rotnode.right = child;
            parent.left = rotnode;
            afterRotate(rotnode, parent, child);
        }
    }
    //旋转之后, 更新它们的parent; 并且更新旋转后的高度  参数：rotnode parent child
    private void afterRotate(Node<K, V> rotnode, Node<K, V> parent, Node<K, V> child) {
        // 让parent为子树的根节点
        parent.parent = rotnode.parent;
        // 如果rotnode是其父节点的left, 则将rotnode.parent.left = parent;
        if (rotnode.isLchild()) {
            rotnode.parent.left = parent;
        } else if (rotnode.isRchild()) {
            rotnode.parent.right = parent;
            // rotnode是根节点
        } else {
            rootnode = parent;
        }
        // 更新child的parent
        if (child != null)
            child.parent = rotnode;
        // 更新rotnode的parent
        rotnode.parent = parent;
    }
    //传入key找到对应红黑树对应的结点, 然后取出k红黑树节点的value   参数：key
    private Node<K, V> getnodevalue(K key) {
        Node<K, V> node = rootnode;
        while (node != null) {
            int count = mycompare(key, node.key);
            if (count == 0) return node;
            if (count > 0) {  // 说明key对应的结点, 比node的key大, 所以去它的右子树找
                node = node.right;
            } else {
                node = node.left;
            }
        }
        return null; // 没有找到key对应的结点
    }
    //比较函数 return： 返回值等于0, 代表e1=e2；大于0,代表e1>e2；小于0,代表e1<e2
    private int mycompare(K k1, K k2) {
        if (mycomparator != null) { // 这里表示传入了比较器
            return mycomparator.compare(k1, k2);
        }
        // 这里表示没有使用比较器,此时再强制将传入的元素实现Comparable接口,并重写接口中的方法
        //return ((Comparable<E>) k1).compareTo(k2);
        return ((Comparable<K>) k1).compareTo(k2);
    }
    //将传来的节点染色(红或黑)   参数：需要染色的节点，要染成的颜色
    private Node<K, V> redOrblack(Node<K, V> node,String corl) {
        if (corl=="red"){
            //System.out.print("传来的节点染成红色"+"\n");
            if (node == null) return node;
            node.color = Corred;
            return node;
        }
        else {
            //System.out.print("传来的节点染成黑色"+"\n");
            if (node == null) return node;
            node.color = Corblack;
            return node;
        }
    }
    //移除节点后的处理
    private void RemoveAfter(Node<K, V> node, Node<K, V> replacement) {
        // 删除的节点, 都是叶子节点
        // 如果删除的节点为红色,则不需要处理
        if ((node == null ? Corblack : node.color) == Corred) return;
        // 用于取代node的节点replacement为红色
        if ((replacement == null ? Corblack : replacement.color) == Corred) {
            // 将替代节点染为黑色
            // System.out.print("调用redOrblack 308");
            redOrblack(replacement,"black");
            return;
        }
        // 删除的是根节点
        Node<K, V> parent = node.parent;
        if (parent == null) return;
        // 删除黑色的叶子节点(肯定会下溢)
        // 判断被删除的node是左还是右(如果直接通过sibling()方法,拿到的不准确,因为在remove方法中已经将node置为null了,然后才调用的afterReNode
        boolean left = parent.left == null || node.isLchild();
        Node<K, V> sibling = left ? parent.right : parent.left;
        if (left) { // 被删除的节点在左边, 兄弟节点在右边
            if ((sibling == null ? Corblack : sibling.color) == Corred) {
                // System.out.print("调用redOrblack 324");
                redOrblack(sibling,"black");
                // System.out.print("调用redOrblack 310");
                redOrblack(parent,"red");
                rotateRightorLeft(parent,"left");
                sibling = parent.right;
            }
            // 兄弟节点必然是黑色 判断是否为黑色：(node == null ? BLACK : node.color) == BLACK
            if (((sibling.left == null ? Corblack : sibling.left.color) == Corblack) && ((sibling.right == null ? Corblack : sibling.right.color) == Corblack)) {  // 表示node的黑兄弟节点的left,right子节点都是黑节点
                boolean parentBlack = ((parent == null ? Corblack : parent.color) == Corblack);
                // System.out.print("调用redOrblack 336");
                redOrblack(parent,"black");
                // System.out.print("调用redOrblack 320");
                redOrblack(sibling,"red");
                if (parentBlack) {
                    RemoveAfter(parent, null);
                }
            } else { // 表示兄弟节点至少有一个红色子节点,可以向被删除节点的位置借一个节点
                if ((sibling.right == null ? Corblack : sibling.right.color) == Corblack) {
                    //rotateRight(sibling);
                    rotateRightorLeft(sibling,"right");
                    sibling = parent.right;
                }
                //color(sibling, parent == null ? BLACK : parent.color);
                sibling.color = (parent == null ? Corblack : parent.color);
                // System.out.print("调用redOrblack 351");
                redOrblack(sibling.right,"black");
                // System.out.print("调用redOrblack 354");
                redOrblack(parent,"black");
                //rotateLeft(parent);
                rotateRightorLeft(parent,"left");
            }
        } else { // 被删除节点在右边, 兄弟节点在左边
            if ((sibling == null ? Corblack : sibling.color) == Corred) { // 兄弟节点是红色
                // System.out.print("调用redOrblack 361");
                redOrblack(sibling,"black");
                // System.out.print("调用redOrblack 339");
                redOrblack(parent,"red");

                //rotateRight(parent);
                rotateRightorLeft(parent,"right");// 旋转之后,改变兄弟节点,然后node的兄弟节点就为黑色了
                // 更换兄弟节点
                sibling = parent.left;
            }
            // 兄弟节点必然是黑色
            if (((sibling.left == null ? Corblack : sibling.left.color) == Corblack) && ((sibling.right == null ? Corblack : sibling.right.color) == Corblack)) {  // 表示node的黑兄弟节点的left,right子节点都是黑节点
                // 兄弟节点没有一个红色子节点(不能借一个节点给你), 父节点要向下跟node的兄弟节点合并
                /*
                    首先这里要判断父节点parent的颜色(如果为parent为红色,则根据B树红色节点向其黑色父节点合并原则,parent向下合并,肯定不会
                    发生下溢; 如果parent为黑色,则说明parent向下合并后,必然也会发生下溢,这里我们当作移除一个叶子结点处理,复用afterReNode
                 */
                boolean parentBlack = ((parent == null ? Corblack : parent.color) == Corblack);
                // 下面两行染色的代码,是说明parent为红色的情况
                // System.out.print("调用redOrblack 382");
                redOrblack(parent,"black");
                // System.out.print("调用redOrblack 385");
                redOrblack(sibling,"red");
                if (parentBlack) {
                    RemoveAfter(parent, null);
                }
            } else { // 表示兄弟节点至少有一个红色子节点,可以向被删除节点的位置借一个节点
                // 兄弟节点的左边是黑色, 先将兄弟节点左旋转; 旋转完之后和后面两种的处理方式相同,都是再对父节点进行右旋转
                if ((sibling.left == null ? Corblack : sibling.left.color) == Corblack) {
                    //rotateLeft(sibling);
                    rotateRightorLeft(sibling,"left");
                    sibling = parent.left; // 因为旋转之后,要更改node的sibling,才能复用下面的染色代码.不然出现bug
                }
                // 旋转之后的中心节点继承parent的颜色; 旋转之后的左右节点染为黑色
                // 先染色,再旋转: 肯定要先对node的sibling先染色
                //color(sibling, parent == null ? BLACK : parent.color);
                System.out.print("color换成赋值"+"\n");
                sibling.color = (parent == null ? Corblack : parent.color);
                // System.out.print("调用redOrblack 399");
                redOrblack(sibling.left,"black");
                // System.out.print("调用redOrblack 402");
                redOrblack(parent,"black");
                //rotateRight(parent);
                rotateRightorLeft(parent,"right");
            }
        }
    }
    //添加节点之后的处理
    private void Addafter(Node<K, V> node) {
        Node<K, V> parent = node.parent;

        // 添加的是根节点(染成黑色)
        if (parent == null) {
            // System.out.print("调用redOrblack 229");
            redOrblack(node,"black");
            return;
        }
        // ------------- 一共 12 种情况--------------
        // 不需要处理的4种情况:  如果父节点是黑色, 直接返回
        if ((parent == null ? Corblack : parent.color) == Corblack) return;

        // 根据uncle节点的颜色来判断其他的各4种情况
        Node<K, V> uncle = parent.sibling();
        // 祖父节点
        Node<K, V> rotnode = parent.parent;

        // 需要处理的4种情况: 叔父节点是红色
        if ((uncle == null ? Corblack : uncle.color) == Corred) {
            // System.out.print("调用redOrblack 245");
            redOrblack(parent,"black");
            // System.out.print("调用redOrblack 248");
            redOrblack(uncle,"black");
            // 把祖父节点染成红色, 当做新添加的节点处理(递归调用afterAdd)
            // System.out.print("调用redOrblack 247");
            Addafter(redOrblack(rotnode,"red"));
            return;
        }

        /*
            因为这4种情况, RBTree需要对节点进行旋转操作; 此时就需要使用到AVLTree中的旋转代码,
            因为AVLTree和RBTree都是平衡二叉搜索树(BalanceBinarySearchTree),BBST在BST的基础上增加了旋转功能;
            为了程序的拓展性, 我们在创建一个BBST 继承 BST, AVLTree和RBTree再继承 BBST
        */
        // 需要处理的4种情况: 叔父节点不是红色(叔父节点为空)
        if (parent.isLchild()) { // L
            // LL,LR, rotnode都要染成红色
            Addafter(redOrblack(rotnode,"red"));
            if (node.isLchild()) { // LL
                // System.out.print("调用redOrblack 270");
                redOrblack(parent,"black");
            } else { // LR
                // System.out.print("调用redOrblack 274");
                redOrblack(node,"black");
                //rotateLeft(parent);
                rotateRightorLeft(parent,"left");
            }
            // LL,LR, rotnode最后都要右旋转
            //rotateRight(rotnode);
            rotateRightorLeft(rotnode,"right");
        } else { // R
            // System.out.print("调用redOrblack 273");
            Addafter(redOrblack(rotnode,"red"));
            if (node.isLchild()) { // RL
                // System.out.print("调用redOrblack 229");
                redOrblack(node,"black");
                //rotateRight(parent);
                rotateRightorLeft(parent,"right");
            } else { // RR
                // System.out.print("调用redOrblack 229");
                redOrblack(parent,"black");
            }
            //rotateLeft(rotnode);
            rotateRightorLeft(rotnode,"left");
        }

    }
    //检查key值
    private void TreeCheck(K key) {
        if (key == null) {
            // 手动抛出异常对象
            throw new IllegalArgumentException("K值集合为空!");
        }
    }
}
