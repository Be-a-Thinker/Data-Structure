package map;
/*
    Map接口
 */
public interface tMap<K, V> {
    int size();//返回map中的映射个数
    boolean isEmpty();//判断map是否为空
    void clear();//清空当前map
    V put(K key, V value); //向map中添加映射
    V get(K key);//获取K值对应的value值
    V remove(K key);//移除K值对应的映射
    boolean containsKey(K key); //判断K值是否存在
    boolean containsValue(V value); //判断value值是否存在
    void traversal(Visitor<K, V> visitor); //遍历map中的元素（visit执行的是打印方法）
    public static abstract class Visitor<K, V> {
        public abstract boolean visitnode(K key, V value);
        boolean quit;
    }
    public static void main(String[] args) {
        TreeMap treeMap = new TreeMap<Integer, String>();
        treeMap.put(10, "A");
        treeMap.put(7, "B");
        treeMap.put(20, "C");
        treeMap.put(13, "D");
        treeMap.put(5, "E");
        treeMap.put(9, "F");
        treeMap.put(11, "G");
        treeMap.put(24, "H");
        System.out.print("开始遍历"+"\n");
        treeMap.traversal(new tMap.Visitor<Integer, String>() {
            public boolean visitnode(Integer key, String value) {
                System.out.print("Key为"+key + "，" +"value为"+ value+"\n");
                return false;
            }
        });
        System.out.println("treemap的size为:"+treeMap.size());
        System.out.println("treemap的是否包含key 10:"+treeMap.containsKey(10));
        System.out.println("treemap的是否包含key 8:"+treeMap.containsKey(8));
        System.out.println("treemap的是否包含value M:"+treeMap.containsValue("M"));
        System.out.println("treemap的是否包含value H:"+treeMap.containsValue("H"));
        System.out.println("9对应的k值为:"+treeMap.get(9));
        treeMap.remove(11);
        System.out.println("treemap remove 11后的size:"+treeMap.size());
        System.out.print("*******************remove 11 后开始遍历*************************："+"\n");
        treeMap.traversal(new tMap.Visitor<Integer, String>() {
            //visit方法（此处执行的是打印操作）
            public boolean visitnode(Integer key, String value) {
                System.out.print("K值为"+key + "，" +"value值为"+ value+"\n");
                return false;
            }
        });
        System.out.println("当前treemap是否为empty:"+treeMap.isEmpty());
        System.out.print("*******************clear*************************："+"\n");
        treeMap.clear();
        System.out.println("treemap clear后的size:"+treeMap.size());
        System.out.println("当前treemap是否为empty:"+treeMap.isEmpty());
    }

}
