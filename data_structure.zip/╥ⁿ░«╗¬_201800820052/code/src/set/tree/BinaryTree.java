package set.tree;
/*
    普通二叉树
 */
public class BinaryTree<E>{
    protected int size;
    // 定义根节点
    protected Node<E> rootnode;
    public int size() {
        return size;
    }
    public boolean isEmpty() {
        return size == 0;
    }
    public void clear() {
        rootnode = null;
        size = 0;
    }
    //中序遍历(左根右 / 右根左), 相当于升序/降序
    public void IdrTraversal(BinarySTree.Visitor<E> visitor) {
        this.IdrTraversal(rootnode, visitor); // 从根节点开始遍历
    }
    private void IdrTraversal(Node<E> node, BinarySTree.Visitor<E> visitor) {
        if (node == null || visitor == null) return;

        IdrTraversal(node.left, visitor);
        visitor.myvisitnode(node.element);
        IdrTraversal(node.right, visitor);
    }
    public interface Visitor<E> {
        boolean myvisitnode(E element);
    }
    protected static class Node<E> {
        E element;
        Node<E> left;
        Node<E> right;
        Node<E> parent;
        // 这里不初始化左,右结点,因为不常用,比如所叶子结点,就灭有左右结点
        // 父节点,除了根节点外,都有父节点
        public Node(E element, Node<E> parent) {
            this.element = element;
            this.parent = parent;
        }
        //判断自己是否左子树
        public boolean isLChild() {
            return parent != null && this == parent.left;
        }
        //判断自己是否右子树
        public boolean isRChild() {
            return parent != null && this == parent.right;
        }
        //判断是否为左右节点都不为空的节点
        public boolean WheterTwoChildren() {
            return left != null && right != null;
        }
        //返回节点的兄弟节点. 注: 节点的叔父节点,即parent.sibling(), 父节点的兄弟节点
        public Node<E> sibling() {
            // 自己是父节点的左子树, 返回父节点的右子树(即兄弟节点)
            if (isLChild()) {
                return parent.right;
            }
            // 自己是父节点的右子树, 返回父节点的左子树(即兄弟节点)
            if (isRChild()) {
                return parent.left;
            }
            // 没有父节点, 即没有兄弟节点
            return null;
        }
    }
    //根据传入的节点, 返回该节点的前驱节点 (中序遍历)
    protected Node<E> NodeAhead(Node<E> node) {
        if (node == null) return node;

        // (中序遍历)前驱节点在左子树当中(node.left.right.right.right...)
        Node<E> nodetmp = node.left;
        // 左子树存在
        if (nodetmp != null) {
            while (nodetmp.right != null) {
                nodetmp = nodetmp.right;
            }
            return nodetmp;
        }
        // 程序走到这里说明左子树不存在; 从父节点、祖父节点中寻找前驱节点
        /*
         * node的父节点不为空 && node是其父节点的左子树时. 就一直往上寻找它的父节点
         *  因为node==node.parent.right, 说明你在你父节点的右边, 那么node.parent就是其node的前驱节点
         */
        while (node.parent != null && node == node.parent.left) {
            node = node.parent;
        }

        // 能来到这里表示: 两种情况如下
        // node.parent == null 表示没有父节点(根节点),返回空 ==> return node.parent;
        // node==node.parent.right 说明你在你父节点的右边, 那么node.parent就是其node的前驱节点 ==> return node.parent;
        return node.parent;
    }
    protected Node<E> NewNode(E element, Node<E> parent) {
        return new Node<>(element, parent);
    }

}
