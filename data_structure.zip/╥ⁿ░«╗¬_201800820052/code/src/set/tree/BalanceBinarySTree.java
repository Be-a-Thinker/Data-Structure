package set.tree;
import java.util.Comparator;
/**
    平衡二叉搜索树(BalanceBinarySearchTree)
        由于RBTree需要对节点进行旋转操作; 此时就需要使用到AVLTree中的旋转代码,
        因为AVLTree和RBTree都是平衡二叉搜索树(BalanceBinarySearchTree),BBST在BST的基础上增加了旋转功能;
        为了程序的拓展性, 我们在创建一个BBST 继承 BST, AVLTree和RBTree再 继承 BBST
 */
public class BalanceBinarySTree<E> extends BinarySTree<E> {
    public BalanceBinarySTree() {
        this(null);
    }
    public BalanceBinarySTree(Comparator<E> comparator) {
        super(comparator);
    }
    //对node进行右旋转 参数：grand
    protected void Rightrotate(Node<E> grand) {
        Node<E> parent = grand.left;
        Node<E> child = parent.right;
        grand.left = child;
        parent.right = grand;
        Rotateafter(grand, parent, child);
    }
    //对node进行左旋转 参数：grand
    protected void rotateLeft(Node<E> grand) {
        Node<E> parent = grand.right;
        Node<E> child = parent.left;
        grand.right = child;
        parent.left = grand;
        Rotateafter(grand, parent, child);
    }
    //旋转之后, 更新它们的parent; 并且更新旋转后的高度
    protected void Rotateafter(Node<E> vastnode, Node<E> parent, Node<E> child) {
        // 让parent为子树的根节点
        parent.parent = vastnode.parent;
        // 如果grand是其父节点的left, 则将grand.parent.left = parent;
        if (vastnode.isLChild()) {
            vastnode.parent.left = parent;
        } else if (vastnode.isRChild()) {
            vastnode.parent.right = parent;
            // grand是根节点
        } else {
            rootnode = parent;
        }
        // 更新child的parent
        if (child != null)
            child.parent = vastnode;
        // 更新grand的parent
        vastnode.parent = parent;
    }
}
