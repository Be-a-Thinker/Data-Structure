package set.tree;
import java.util.Comparator;
/*
    红黑树
 */
public class RedBlackTree<E> extends BalanceBinarySTree<E> {
    private static final boolean Corred = false;
    private static final boolean Corblack = true;
    public RedBlackTree() {
        this(null);
    }
    public RedBlackTree(Comparator<E> comparator) {
        super(comparator);
    }
    protected Node<E> NewNode(E element, Node<E> parent) {
        return new ProNode<>(element, parent);
    }
    private static class ProNode<E> extends Node<E> {
        boolean color;
        public ProNode(E element, Node<E> parent) {
            super(element, parent);
        }
        public String toString() {
            String tmp = "";
            // 红色加 R_, 默认黑色
            if (color == Corred) {
                tmp = "R_";
            }
            return tmp + element.toString();
        }
    }
    protected void Removeafter(Node<E> node, Node<E> replacement) {
        // 删除的节点, 都是叶子节点
        // 如果删除的节点为红色,则不需要处理
        if (WheterRed(node)) return;
        // 用于取代node的节点replacement为红色
        if (WheterRed(replacement)) {
            // 将替代节点染为黑色
            ToBlack(replacement);
            return;
        }
        // 删除的是根节点
        Node<E> parent = node.parent;
        if (parent == null) return;
        // 删除黑色的叶子节点(肯定会下溢)
        // 判断被删除的node是左还是右(如果直接通过sibling()方法,拿到的不准确,因为在remove方法中已经将node置为null了,然后才调用的afterRemove
        boolean left = parent.left == null || node.isLChild();
        Node<E> sibling = left ? parent.right : parent.left;
        if (left) { // 被删除的节点在左边, 兄弟节点在右边
            if (WheterRed(sibling)) {
                ToBlack(sibling);
                ToRed(parent);
                rotateLeft(parent);
                sibling = parent.right;
            }
            // 兄弟节点必然是黑色
            if (wheterBlack(sibling.left) && wheterBlack(sibling.right)) {  // 表示node的黑兄弟节点的left,right子节点都是黑节点
                boolean parentBlack = wheterBlack(parent);
                ToBlack(parent);
                ToRed(sibling);
                if (parentBlack) {
                    Removeafter(parent, null);
                }
            } else { // 表示兄弟节点至少有一个红色子节点,可以向被删除节点的位置借一个节点
                if (wheterBlack(sibling.right)) {
                    Rightrotate(sibling);
                    sibling = parent.right;
                }
                coloring(sibling, GetColor(parent));
                ToBlack(sibling.right);
                ToBlack(parent);
                rotateLeft(parent);
            }
        } else { // 被删除节点在右边, 兄弟节点在左边
            if (WheterRed(sibling)) { // 兄弟节点是红色
                ToBlack(sibling);
                ToRed(parent);
                Rightrotate(parent); // 旋转之后,改变兄弟节点,然后node的兄弟节点就为黑色了
                // 更换兄弟节点
                sibling = parent.left;
            }
            // 兄弟节点必然是黑色
            if (wheterBlack(sibling.left) && wheterBlack(sibling.right)) {  // 表示node的黑兄弟节点的left,right子节点都是黑节点
                // 兄弟节点没有一个红色子节点(不能借一个节点给你), 父节点要向下跟node的兄弟节点合并
                /*
                    首先这里要判断父节点parent的颜色(如果为parent为红色,则根据B树红色节点向其黑色父节点合并原则,parent向下合并,肯定不会
                    发生下溢; 如果parent为黑色,则说明parent向下合并后,必然也会发生下溢,这里我们当作移除一个叶子结点处理,复用afterRemove
                 */
                boolean PaBlack = wheterBlack(parent);
                // 下面两行染色的代码,是说明parent为红色的情况
                ToBlack(parent);
                ToRed(sibling);
                if (PaBlack) {
                    Removeafter(parent, null);
                }
            } else { // 表示兄弟节点至少有一个红色子节点,可以向被删除节点的位置借一个节点
                // 兄弟节点的左边是黑色, 先将兄弟节点左旋转; 旋转完之后和后面两种的处理方式相同,都是再对父节点进行右旋转
                if (wheterBlack(sibling.left)) {
                    rotateLeft(sibling);
                    sibling = parent.left; // 因为旋转之后,要更改node的sibling,才能复用下面的染色代码.不然出现bug
                }
                // 旋转之后的中心节点继承parent的颜色; 旋转之后的左右节点染为黑色
                // 先染色,再旋转: 肯定要先对node的sibling先染色
                coloring(sibling, GetColor(parent));
                ToBlack(sibling.left);
                ToBlack(parent);
                Rightrotate(parent);
            }
        }
    }
    protected void Addafter(Node<E> node) {
        Node<E> parent = node.parent;
        // 添加的是根节点(染成黑色)
        if (parent == null) {
            ToBlack(node);
            return;
        }
        // ------------- 一共 12 种情况--------------
        // 不需要处理的4种情况:  如果父节点是黑色, 直接返回
        if (wheterBlack(parent)) return;
        // 根据uncle节点的颜色来判断其他的各4种情况
        Node<E> uncle = parent.sibling();
        // 祖父节点
        Node<E> vastnode = parent.parent;

        // 需要处理的4种情况: 叔父节点是红色
        if (WheterRed(uncle)) {
            ToBlack(parent);
            ToBlack(uncle);
            // 把祖父节点染成红色, 当做新添加的节点处理(递归调用afterAdd)
            Addafter(ToRed(vastnode));
            return;
        }
        /*
            因为这4种情况, RBTree需要对节点进行旋转操作; 此时就需要使用到AVLTree中的旋转代码,
            因为AVLTree和RBTree都是平衡二叉搜索树(BalanceBinarySearchTree),BBST在BST的基础上增加了旋转功能;
            为了程序的拓展性, 我们在创建一个BBST 继承 BST, AVLTree和RBTree再 继承 BBST
        */
        // 需要处理的4种情况: 叔父节点不是红色(叔父节点为空)
        if (parent.isLChild()) { // L
            // LL,LR, grand都要染成红色
            ToRed(vastnode);
            if (node.isLChild()) { // LL
                ToBlack(parent);
            } else { // LR
                ToBlack(node);
                rotateLeft(parent);
            }
            // LL,LR, grand最后都要右旋转
            Rightrotate(vastnode);
        } else { // R
            ToRed(vastnode);
            if (node.isLChild()) { // RL
                ToBlack(node);
                Rightrotate(parent);
            } else { // RR
                ToBlack(parent);
            }
            rotateLeft(vastnode);
        }
    }
    //传进来的节点染成红色
    private Node<E> ToRed(Node<E> node) {
        return coloring(node, Corred);
    }
    //传进来的节点染成黑色
    private Node<E> ToBlack(Node<E> node) {
        return coloring(node, Corblack);
    }
    //将node染成color色
    private Node<E> coloring(Node<E> node, boolean color) {
        if (node == null) return node;
        ((ProNode<E>) node).color = color;
        return node;
    }
    //返回当前节点的颜色
    private boolean GetColor(Node<E> node) {
        return node == null ? Corblack : ((ProNode<E>) node).color;
    }
    //节点是否为红色
    private boolean WheterRed(Node<E> node) {
        return GetColor(node) == Corred;
    }
    //节点是否为黑色
    private boolean wheterBlack(Node<E> node) {
        return GetColor(node) == Corblack;
    }
}
