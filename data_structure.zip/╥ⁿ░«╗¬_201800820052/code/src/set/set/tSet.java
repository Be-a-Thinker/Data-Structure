package set.set;
/*
    TreeSet的接口
 */
public interface tSet<E> {
    int size();
    boolean isEmpty();
    void clear();
    boolean contains(E element);
    void add(E element);
    void remove(E element);
    void traversal(Visitor<E> visitor); //遍历集合
    public static abstract class Visitor<E> {
        public abstract boolean myvisitnode(E element);
        boolean quit;
    }
    public static void main(String[] args) {
        // 创建Set
        TreeSet<Integer> mts = new TreeSet<>();
        // 查看初始化情况
        System.out.println("初始size为:" + mts.size());
        System.out.println("初始Set是否为空："+mts.isEmpty());
        for (int i = 0; i < 10; i++) {
            mts.add(i / 2);
            mts.add(i * 3);
            mts.add(i);
        }
        mts.add(12);
        System.out.println("从小到大开始遍历");
        mts.traversal(new tSet.Visitor<Integer>() {
            //visit方法（以打印操作为例）
            public boolean myvisitnode(Integer element) {
                System.out.println("当前元素为："+element+";");
                return false;
            }
        });
        System.out.println("当前的size为:" + mts.size());
        System.out.println("集合是否包含13:" + mts.contains(13));
        System.out.println("集合是否包含27:" + mts.contains(27));
        System.out.println("****************************删除27**************************");
        mts.remove(27);
        System.out.println("删除27后size为:" + mts.size());
        System.out.println("是否为empty:"+mts.isEmpty());
        System.out.println("****************************clear**************************");
        mts.clear();
        System.out.println("clear后的size:" + mts.size());
        System.out.println("是否为empty:"+mts.isEmpty());
    }
}


