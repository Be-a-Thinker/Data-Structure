package set.set;

import set.tree.BinaryTree;
import set.tree.RedBlackTree;
import java.util.Comparator;

//使用红黑树实现TreeSet
public class TreeSet<E> implements tSet<E> {

    private RedBlackTree<E> mytree;

    public TreeSet() {
        this(null);
    }

    public TreeSet(Comparator<E> comparator) {
        mytree = new RedBlackTree<>(comparator);
    }

    public int size() {
        return mytree.size();
    }

    public boolean isEmpty() {
        return mytree.isEmpty();
    }

    public void clear() {
        mytree.clear();
    }

    public boolean contains(E element) {
        return mytree.contains(element);
    }

    public void add(E element) {
        // RBTree中默认就是去重的
        mytree.add(element);
    }

    public void remove(E element) {
        mytree.remove(element);
    }

    public void traversal(Visitor<E> visitor) {
        // 中序遍历visit每一个节点
        mytree.IdrTraversal(new BinaryTree.Visitor<E>() {
            public boolean myvisitnode(E element) {
                return visitor.myvisitnode(element);
            }
        });
    }
}
